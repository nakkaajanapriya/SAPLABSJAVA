// Transactions: {id, title, amount, type, date}
let transactions = loadFromStorage();

// Elements
const balanceEl = document.getElementById("balance");
const incomeTotalEl = document.getElementById("incomeTotal");
const expenseTotalEl = document.getElementById("expenseTotal");

const form = document.getElementById("txForm");
const titleEl = document.getElementById("title");
const amountEl = document.getElementById("amount");
const typeEl = document.getElementById("type");
const dateEl = document.getElementById("date");

const titleErr = document.getElementById("titleErr");
const amountErr = document.getElementById("amountErr");
const typeErr = document.getElementById("typeErr");
const successMsg = document.getElementById("successMsg");

const txList = document.getElementById("txList");
const searchEl = document.getElementById("search");
const clearAllBtn = document.getElementById("clearAllBtn");

// Helpers
function money(n){ return `₹${n.toLocaleString("en-IN")}`; }

function todayISO(){
  const d = new Date();
  const yyyy = d.getFullYear();
  const mm = String(d.getMonth() + 1).padStart(2, "0");
  const dd = String(d.getDate()).padStart(2, "0");
  return `${yyyy}-${mm}-${dd}`;
}

dateEl.value = todayISO();

function clearErrors(){
  titleErr.textContent = "";
  amountErr.textContent = "";
  typeErr.textContent = "";
  successMsg.textContent = "";
}

function validate(){
  clearErrors();

  const title = titleEl.value.trim();
  const amount = Number(amountEl.value);
  const type = typeEl.value;

  let ok = true;

  if (title.length < 2){
    titleErr.textContent = "Title must be at least 2 characters.";
    ok = false;
  }

  if (!Number.isFinite(amount) || amount <= 0){
    amountErr.textContent = "Enter a valid amount greater than 0.";
    ok = false;
  }

  if (!type){
    typeErr.textContent = "Please select income or expense.";
    ok = false;
  }

  return ok;
}

// Storage
function saveToStorage(){
  localStorage.setItem("expenseTrackerTx", JSON.stringify(transactions));
}
function loadFromStorage(){
  const raw = localStorage.getItem("expenseTrackerTx");
  return raw ? JSON.parse(raw) : [];
}

// Calculate totals using loops
function calculateSummary(list){
  let income = 0;
  let expense = 0;

  for (let i = 0; i < list.length; i++){
    const tx = list[i];
    if (tx.type === "income") income += tx.amount;
    else expense += tx.amount;
  }

  const balance = income - expense;
  return { income, expense, balance };
}

function renderSummary(){
  const s = calculateSummary(transactions);

  balanceEl.textContent = money(s.balance);
  incomeTotalEl.textContent = money(s.income);
  expenseTotalEl.textContent = money(s.expense);

  // optional visual: balance color
  balanceEl.style.color = s.balance >= 0 ? "#b9ffcf" : "#ffb4b4";
}

// Render list (with filter)
function renderList(){
  const q = searchEl.value.trim().toLowerCase();

  const filtered = [];
  for (let i = 0; i < transactions.length; i++){
    const tx = transactions[i];
    if (!q || tx.title.toLowerCase().includes(q)) filtered.push(tx);
  }

  txList.innerHTML = "";

  if (filtered.length === 0){
    txList.innerHTML = `<p class="muted">No transactions found.</p>`;
    return;
  }

  for (let i = 0; i < filtered.length; i++){
    const tx = filtered[i];

    const wrap = document.createElement("div");
    wrap.className = "tx";

    const amtClass = tx.type === "income" ? "income" : "expense";
    const sign = tx.type === "income" ? "+" : "-";

    wrap.innerHTML = `
      <div class="tx-left">
        <span class="tx-title">${tx.title}</span>
        <span class="tx-date">${tx.date || "-"}</span>
      </div>

      <div class="tx-actions">
        <span class="tx-amount ${amtClass}">${sign}${money(tx.amount)}</span>
        <button class="icon-btn" data-del="${tx.id}">Delete</button>
      </div>
    `;

    txList.appendChild(wrap);
  }
}

// Add transaction
form.addEventListener("submit", (e) => {
  e.preventDefault();
  if (!validate()) return;

  const tx = {
    id: crypto.randomUUID(),
    title: titleEl.value.trim(),
    amount: Number(amountEl.value),
    type: typeEl.value,
    date: dateEl.value || todayISO()
  };

  transactions.unshift(tx); // add to top
  saveToStorage();

  successMsg.textContent = "✅ Added successfully!";
  form.reset();
  dateEl.value = todayISO();

  renderSummary();
  renderList();
});

// Delete transaction (event delegation)
txList.addEventListener("click", (e) => {
  const btn = e.target.closest("button[data-del]");
  if (!btn) return;

  const id = btn.getAttribute("data-del");

  const newArr = [];
  for (let i = 0; i < transactions.length; i++){
    if (transactions[i].id !== id) newArr.push(transactions[i]);
  }
  transactions = newArr;

  saveToStorage();
  renderSummary();
  renderList();
});

// Search
searchEl.addEventListener("input", renderList);

// Clear all
clearAllBtn.addEventListener("click", () => {
  transactions = [];
  saveToStorage();
  renderSummary();
  renderList();
});

// Init
renderSummary();
renderList();
