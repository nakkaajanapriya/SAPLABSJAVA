// Footer year
document.getElementById("year").textContent = new Date().getFullYear();

// Contact form validation
const form = document.getElementById("contactForm");

const nameInput = document.getElementById("name");
const emailInput = document.getElementById("email");
const messageInput = document.getElementById("message");

const nameError = document.getElementById("nameError");
const emailError = document.getElementById("emailError");
const messageError = document.getElementById("messageError");
const successMsg = document.getElementById("successMsg");

function isValidEmail(email) {
  // simple reliable pattern
  return /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email);
}

function setError(el, message) {
  el.textContent = message;
}

function clearErrors() {
  nameError.textContent = "";
  emailError.textContent = "";
  messageError.textContent = "";
  successMsg.textContent = "";
}

form.addEventListener("submit", (e) => {
  e.preventDefault();
  clearErrors();

  const name = nameInput.value.trim();
  const email = emailInput.value.trim();
  const message = messageInput.value.trim();

  let ok = true;

  // Name
  if (name.length < 3) {
    setError(nameError, "Name must be at least 3 characters.");
    ok = false;
  }

  // Email
  if (!isValidEmail(email)) {
    setError(emailError, "Please enter a valid email address.");
    ok = false;
  }

  // Message
  if (message.length < 10) {
    setError(messageError, "Message must be at least 10 characters.");
    ok = false;
  }

  if (ok) {
    successMsg.textContent = "✅ Message sent successfully! (Demo validation only)";
    form.reset();
  }
});

// Live validation (optional nice UX)
nameInput.addEventListener("input", () => {
  if (nameInput.value.trim().length >= 3) nameError.textContent = "";
});
emailInput.addEventListener("input", () => {
  if (isValidEmail(emailInput.value.trim())) emailError.textContent = "";
});
messageInput.addEventListener("input", () => {
  if (messageInput.value.trim().length >= 10) messageError.textContent = "";
});
