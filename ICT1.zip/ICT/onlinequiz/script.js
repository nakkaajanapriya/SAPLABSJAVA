// Quiz Questions (you can edit / add more)
const questions = [
  {
    q: "Which language is used to style web pages?",
    options: ["HTML", "CSS", "Java", "Python"],
    answerIndex: 1
  },
  {
    q: "Which tag is semantic?",
    options: ["<div>", "<span>", "<section>", "<b>"],
    answerIndex: 2
  },
  {
    q: "Which is used to make a webpage interactive?",
    options: ["CSS", "HTML", "JavaScript", "C"],
    answerIndex: 2
  },
  {
    q: "Which of these is a loop in JavaScript?",
    options: ["repeat", "for", "if", "select"],
    answerIndex: 1
  },
  {
    q: "What does DOM stand for?",
    options: ["Document Object Model", "Data Object Method", "Design Online Model", "Document Option Mode"],
    answerIndex: 0
  }
];

// State
let current = 0;
let selected = new Array(questions.length).fill(null); // store chosen option index

// Elements
const quizCard = document.getElementById("quizCard");
const resultCard = document.getElementById("resultCard");

const questionText = document.getElementById("questionText");
const optionsForm = document.getElementById("optionsForm");

const progressText = document.getElementById("progressText");
const scorePill = document.getElementById("scorePill");
const errorMsg = document.getElementById("errorMsg");

const prevBtn = document.getElementById("prevBtn");
const nextBtn = document.getElementById("nextBtn");
const restartBtn = document.getElementById("restartBtn");

const finalScore = document.getElementById("finalScore");
const finalPercent = document.getElementById("finalPercent");
const resultText = document.getElementById("resultText");

// Render question
function renderQuestion() {
  errorMsg.textContent = "";

  const total = questions.length;
  const qObj = questions[current];

  progressText.textContent = `Question ${current + 1} of ${total}`;
  questionText.textContent = qObj.q;

  // Build options
  optionsForm.innerHTML = "";
  for (let i = 0; i < qObj.options.length; i++) {
    const opt = qObj.options[i];

    const label = document.createElement("label");
    label.className = "option";

    const input = document.createElement("input");
    input.type = "radio";
    input.name = "option";
    input.value = i;

    // restore selection
    if (selected[current] === i) input.checked = true;

    input.addEventListener("change", () => {
      selected[current] = i;
      updateScorePill(); // live score preview
      errorMsg.textContent = "";
    });

    const span = document.createElement("span");
    span.textContent = opt;

    label.appendChild(input);
    label.appendChild(span);
    optionsForm.appendChild(label);
  }

  prevBtn.disabled = current === 0;

  // Change Next button to Submit on last question
  if (current === total - 1) nextBtn.textContent = "Submit";
  else nextBtn.textContent = "Next";
}

// Score calculation
function calculateScore() {
  let score = 0;
  for (let i = 0; i < questions.length; i++) {
    if (selected[i] === questions[i].answerIndex) score++;
  }
  return score;
}

function updateScorePill() {
  const score = calculateScore();
  scorePill.textContent = `Score: ${score}`;
}

// Show result
function showResult() {
  const total = questions.length;
  const score = calculateScore();
  const percent = Math.round((score / total) * 100);

  quizCard.classList.add("hidden");
  resultCard.classList.remove("hidden");

  finalScore.textContent = `${score}/${total}`;
  finalPercent.textContent = `${percent}%`;

  // simple message
  let msg = "Good attempt!";
  if (percent >= 80) msg = "Excellent! 🎉";
  else if (percent >= 60) msg = "Good job! ✅";
  else if (percent >= 40) msg = "Nice try — keep practicing 💪";
  else msg = "Don’t worry — try again 👍";

  resultText.textContent = msg;
}

// Events
nextBtn.addEventListener("click", () => {
  // Must choose an option before proceeding
  if (selected[current] === null) {
    errorMsg.textContent = "Please select an option to continue.";
    return;
  }

  const last = questions.length - 1;

  if (current === last) {
    showResult();
  } else {
    current++;
    renderQuestion();
  }
});

prevBtn.addEventListener("click", () => {
  if (current > 0) {
    current--;
    renderQuestion();
  }
});

restartBtn.addEventListener("click", () => {
  current = 0;
  selected = new Array(questions.length).fill(null);
  scorePill.textContent = "Score: 0";
  resultCard.classList.add("hidden");
  quizCard.classList.remove("hidden");
  renderQuestion();
});

// Init
renderQuestion();
updateScorePill();
