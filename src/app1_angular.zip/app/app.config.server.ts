import { ApplicationConfig } from '@angular/core';

export const appConfigServer: ApplicationConfig = {
  providers: [],
};
